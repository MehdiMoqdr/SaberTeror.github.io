<?php
namespace shad;

use shad\tools\Network;

class Client extends Network
{
    private Network $net;
    private string $auth;
    private string $phone;

    public function __construct(?string $auth = null)
    {
        $auth = is_null($auth) || empty($auth) ? $this->generateAuth(32) : $auth;
        $this->auth = $auth;
        parent::__construct($auth);
        $this->net = new Network($auth);
    }

    public function __tostring()
    {
        return $this->auth;
    }

    public function sendSMS(string $phone, ?string $pass_key = null)
    {
        $phone = $this->numberFormater($phone);
        if (!$phone) {
            return "invalid Phone";
        }
        $payload = [
            "phone_number" => $phone,
            "send_type" => "SMS"
        ];
        if (!is_null($pass_key) && !empty($pass_key))
            $payload["pass_key"] = $pass_key;

        $this->phone = $phone;
        return $this->net->init(
            "sendCode",
            $payload,
            true
        );
    }

    public function signIn(string $code, string $hash, string $phone)
    {
        if (is_null($phone)) {
            $phone = $this->phone ?? false;
        } else {
            $phone = $this->numberFormater($phone);
        }

        if (!$phone) {
            return "invalid Phone : $phone";
        }
        $payload = [
            "phone_code" => $code,
            "phone_code_hash" => $hash,
            "phone_number" => $phone
        ];
        return $this->net->init("signIn", $payload, true);
    }

    public function registerDevice($log_name = "rub:coder95")
    {
        $payload = [
            "app_version" => "MA_3.6.5",
            "device_hash" => "90EC014117A2848CC45DEC2B90BD0C4A",
            "device_model" => $log_name,
            "lang_code" => "fa",
            "system_version" => "SDK 23",
            "token" => "",
            "token_type" => "Firebase"
        ];
        return $this->net->init("registerDevice", $payload);
    }

    public function getChats()
    {
        return $this->net->init("getChats");
    }

    public function getUserInfo()
    {
        return $this->net->init("getUserInfo");
    }

    public function uploadAvatar(string $url, ?string $guid = null)
    {
        if (empty($guid) && is_null($guid)) {
            $guid = $this->getUserInfo()["user"]["user_guid"] ?? false;
            if ($guid === false) {
                return "error get guid";
            }
        }
        $upload_info = $this->UploadedFile($url);
        if (!$upload_info["status"]) {
            return $upload_info["message"];
        }
        $payload = [
            "object_guid" => $guid,
            "thumbnail_file_id" => $upload_info["file_id"],
            "main_file_id" => $upload_info["file_id"]
        ];
        return $this->net->init("uploadAvatar", $payload);
    }

    private function requestSendFile(string $file_name, string $size, string $mime = "jpg")
    {
        $payload = [
            "file_name" => $file_name,
            "size" => $size,
            "mime" => $mime
        ];
        return $this->net->init("requestSendFile", $payload);
    }

    private function sendFileRaw(
        string $filePath,
        string $uploadUrl,
        string $fileId,
        string $accessHashSend,
        int $partNumber = 1,
        int $totalParts = 1
    ): array|string {
        $fileData = file_get_contents($filePath);
        if ($fileData === false) {
            return ["status" => false, "message" => "Failed to read file"];
        }

        $headers = [
            "part-number: {$partNumber}",
            "total-part: {$totalParts}",
            "auth: {$this->auth}",
            "access-hash-send: {$accessHashSend}",
            "file-id: {$fileId}",
            "chunk-size: " . strlen($fileData),
            "content-length: " . strlen($fileData),
            "Content-Type: application/octet-stream",
            "accept-encoding: gzip",
            "User-Agent: 3.12.1"
        ];

        $ch = curl_init($uploadUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_POSTFIELDS => $fileData
        ]);

        $response = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);

        if ($response === false) {
            return ["status" => false, "message" => $error];
        }

        $json = json_decode($response, true);
        return is_array($json) ? $json : ["status" => true, "res" => $response];
    }



    public function UploadedFile(string $fileUrl, ?string $customMime = null): array
    {

        $fileName = basename(parse_url($fileUrl, PHP_URL_PATH)) ?: "file_" . time();
        $mimeType = $customMime ?: pathinfo($fileUrl, PATHINFO_EXTENSION);

        $fileSize = strlen(@file_get_contents($fileUrl));
        $pr = self::requestSendFile($fileName, $fileSize);

        if (!$pr || !isset($pr["upload_url"], $pr["id"], $pr["access_hash_send"])) {
            return [
                "status" => false,
                "message" => "Failed to get upload URL",
            ];
        }
        $response = $this->sendFileRaw(
            $fileUrl,
            $pr["upload_url"],
            $pr["id"],
            $pr["access_hash_send"],
            1,
            1
        );

        if (is_array($response) && isset($response["data"]["access_hash_rec"])) {
            return [
                "status" => true,
                "message" => true,
                "dc_id" => $pr["dc_id"],
                "file_id" => $pr["id"],
                "file_name" => $fileName,
                "file_size" => $fileSize,
                "mime" => $mimeType,

            ];
        }

        return [
            "status" => false,
            "message" => "Upload error",
            "res" => $response
        ];
    }




    protected function numberFormater(string $number)
    {
        $number = preg_replace("/\D+/", "", $number);
        if (strpos($number, "0098") === 0) {
            $number = substr($number, 2);
        }
        if (strpos($number, "0") === 0) {
            $number = "98" . substr($number, 1);
        }
        if (preg_match("/^9\d{9}$/", $number)) {
            $number = "98" . $number;
        }
        if (preg_match("/^98(9\d{9})$/", $number)) {
            return $number;
        }
        return false;
    }
    protected function generateAuth($length = 32): string
    {
        $characters = "abcdefghijklmnopqrstuvwxyz";
        $String = "";
        for ($i = 0; $i < $length; $i++) {
            $String .= $characters[rand(0, strlen($characters) - 1)];
        }
        return $String;
    }
}
