<?php
namespace shad\tools;

class Network extends Crypto
{
    private string $auth;
    private string $base_url = "https://shadmessenger38.iranlms.ir/";
    private Crypto $enc;

    private array $cli_web =
        [
            "app_name" => "Main",
            "app_version" => "3.2.3",
            "platform" => "Web",
            "package" => "web.shad.ir",
            "lang_code" => "fa"
        ]
    ;

    private array $cli_and =
        [
            "app_name" => "Main",
            "app_version" => "3.6.5",
            "lang_code" => "fa",
            "package" => "ir.medu.shad",
            "platform" => "Android"

        ]
    ;

    private array $headers = [
        "accept: application/json, text/plain, */*",
        "accept-language: en-US,en;q=0.9,fa;q=0.8",
        "content-type: text/plain",
        "referer: https://web.shad.ir/",
        "user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"
    ];

    public function __construct(?string $auth)
    {
        $this->auth = $auth ?? "inkexmexhgqtgtfaluvzpcvbzadnlsbm";
        parent::__construct($auth);
        $this->enc = new Crypto($auth);
    }

    public function init(string $method, array $input = [], bool $web = false): array|string|null
    {
        if ($web) {
            $config = [
                "method" => $method,
                "input" => $input,
                "client" => $this->cli_web
            ];
        } else {
            $config = $input;
        }
        
        return $this->post(
            $this->enc->encrypt(
                json_encode($config, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
            ),
            $method,
            $web
        );
    }

    protected function post($data_en, string $method, $web = false): array|string|null
    {
        $auth_type = in_array($method, [
            "sendCode",
            "signIn"
        ]) ? "tmp_session" : "auth";
        if ($web) {
            $data = [
                "api_version" => "5",
                $auth_type => $this->auth,
                "data_enc" => $data_en
            ];
        } else {
            $data = [
                "api_version" => "4",
                "auth" => $this->auth,
                "client" => $this->cli_and,
                "data_enc" => $data_en,
                "method" => $method
            ];
        }

        $ch = curl_init();

        curl_setopt_array($ch, [
            CURLOPT_URL => $this->base_url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => $this->headers,
            CURLOPT_POSTFIELDS => json_encode($data),
        ]);

        $response = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);

        if ($err) {
            return $err;
        }

        $res = json_decode($response, true);
        if (!$res || !isset($res["data_enc"])) {
            return $res;
        }

        $result = json_decode(
            $this->enc->decrypt($res["data_enc"]),
            true
        );

        return $result ?: $res;
    }
}