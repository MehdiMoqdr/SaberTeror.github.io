<?php
namespace shad\tools;

use phpseclib3\Crypt\AES;

class Crypto
{
    private string $auth;
    private string $iv;

    public function __construct(?string $auth)
    {
        $this->auth = $auth ?? "inkexmexhgqtgtfaluvzpcvbzadnlsbm";
        $this->iv = str_repeat("\x00", 16);
    }

    private function setAuth(string $auth): string
    {
        return preg_replace_callback('/[a-zA-Z0-9]/', function ($matches) {
            $char = $matches[0];
            if (ctype_lower($char)) {
                return chr(((32 - (ord($char) - 97)) % 26) + 97);
            } elseif (ctype_upper($char)) {
                return chr(((29 - (ord($char) - 65)) % 26) + 65);
            } elseif (ctype_digit($char)) {
                return chr(((13 - (ord($char) - 48)) % 10) + 48);
            }
            return $char;
        }, $auth);
    }

    private function secret(string $auth): string
    {
        $t = substr($auth, 0, 8);
        $i = substr($auth, 8, 8);
        $n = substr($auth, 16, 8) . $t . substr($auth, 24, 8) . $i;

        for ($s = 0, $length = strlen($n); $s < $length; $s++) {
            $char = $n[$s];
            $n[$s] = ctype_digit($char)
                ? chr((ord($char) - ord('0') + 5) % 10 + ord('0'))
                : chr((ord($char) - ord('a') + 9) % 26 + ord('a'));
        }

        return $n;
    }

    public function encrypt(string $data, bool $setAuth = false): string
    {
        $auth = $setAuth
            ? $this->secret($this->setAuth($this->auth))
            : $this->secret($this->auth)
        ;

        $aes = new AES('cbc');
        $aes->setKey($auth);
        $aes->setIV($this->iv);

        $encrypted = $aes->encrypt($data);

        return base64_encode($encrypted);
    }

    public function decrypt(string $data, bool $setAuth = false): ?string
    {
        $auth = $setAuth
            ? $this->secret($this->setAuth($this->auth))
            : $this->secret($this->auth)
        ;

        $aes = new AES('cbc');
        $aes->setKey($auth);
        $aes->setIV($this->iv);

        $decodedData = base64_decode($data, true);
        if ($decodedData === false) {
            return null;
        }

        return $aes->decrypt($decodedData);
    }
}