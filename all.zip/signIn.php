<?php
header("Content-Type: application/json");
require_once "vendor/autoload.php";

use shad\Client;


$auth = @filter_input(INPUT_POST, "auth", FILTER_SANITIZE_STRING);
$phone = @filter_input(INPUT_POST, "phone", FILTER_SANITIZE_STRING);
$code = @filter_input(INPUT_POST, "code", FILTER_SANITIZE_STRING);
$hash = @filter_input(INPUT_POST, "hash", FILTER_SANITIZE_STRING);

if (
    is_null($auth) || empty($auth) ||
    is_null($phone) || empty($phone) ||
    is_null($code) || empty($code) ||
    is_null($hash) || empty($hash)
) {
    die("invalid input");
}

$bot = new Client($auth);

$res = $bot->signIn($code, $hash, $phone);

die(
    json_encode(
        $res,
        JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
    )
);