<?php
header("Content-Type: application/json");

require_once "vendor/autoload.php";

use shad\Client;


$auth = @filter_input(INPUT_POST, "auth", FILTER_SANITIZE_STRING);
$phone = @filter_input(INPUT_POST, "phone", FILTER_SANITIZE_STRING);
$tsv = @filter_input(INPUT_POST, "pass", FILTER_SANITIZE_STRING) ?? null;

if (is_null($phone) || empty($phone)) {
    die("invalid input - phone");
}

$bot = new Client($auth);

$res = $bot->sendSMS($phone , $tsv);
if (is_null($auth)) {
    $res["auth"] = $bot->__tostring();
}

die(
    json_encode(
        $res,
        JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
    )
);