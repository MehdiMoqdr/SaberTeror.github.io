<?php

header("Content-Type: application/json");

require_once "vendor/autoload.php";

use shad\Client;

$auth = @filter_input(INPUT_POST, "auth", FILTER_SANITIZE_STRING);
$url = @filter_input(INPUT_POST, "url", FILTER_SANITIZE_URL);

if (empty($url) || empty($auth) || is_null($url) || is_null($auth)) {
    die("invalid input - auth , url");
}

$bot = new Client($auth);
$res = $bot->uploadAvatar($url);

die(
    json_encode(
        $res,
        JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
    )
);